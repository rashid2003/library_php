<?php
 include 'inc/setting.php';
 include 'inc/db_config.php';





?>
